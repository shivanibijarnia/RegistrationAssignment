package com.cg.forms.test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class FormRegister {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "D:\\software\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://localhost:8085/Forms/");
		Register1Page page1 = PageFactory.initElements(driver, Register1Page.class);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		page1.firstname.sendKeys("Shivani");
		page1.lastname.sendKeys("Bijarnia");
		page1.email.sendKeys("shivani.bijarnia@capgemini.com");
		page1.contact.sendKeys("9900000000");
		page1.address.sendKeys("Malviya Nagar");
		page1.city.sendKeys("Jaipur");
		Select select = new Select(page1.state);
		select.selectByVisibleText("Rajasthan");
		page1.submit.click();
		
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		Register2Page page2 = PageFactory.initElements(driver, Register2Page.class);
		page2.projectdetails.sendKeys("Details");
		page2.projectname.sendKeys("Name");
		page2.clientname.sendKeys("Client Name");
		page2.teamsize.sendKeys("1");
		page2.submit.click();

	}

}
