package com.cg.forms.test;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class Register1Page {
	@FindBy(how = How.ID, using = "firstname")
	WebElement firstname;
	
	@FindBy(how = How.ID, using = "lastname")
	WebElement lastname;
	
	@FindBy(how = How.ID, using = "email")
	WebElement email;
	
	@FindBy(how = How.ID, using = "contact")
	WebElement contact;
	
	@FindBy(how = How.ID, using = "address")
	WebElement address;
	
	@FindBy(how = How.ID, using = "city")
	WebElement city;
	
	@FindBy(how = How.ID, using = "state")
	WebElement state;
	
	@FindBy(how = How.ID, using = "submit")
	WebElement submit;
}
