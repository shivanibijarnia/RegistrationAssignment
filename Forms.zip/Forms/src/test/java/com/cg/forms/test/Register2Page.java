package com.cg.forms.test;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class Register2Page {
	@FindBy(how = How.ID, using = "project-details")
	WebElement projectdetails;
	
	@FindBy(how = How.ID, using = "project-name")
	WebElement projectname;
	
	@FindBy(how = How.ID, using = "client-name")
	WebElement clientname;
	
	@FindBy(how = How.ID, using = "team-size")
	WebElement teamsize;
	
	@FindBy(how = How.ID, using = "submit")
	WebElement submit;
}
